package main

import (
	"fmt"
	"net"
	"sync"
	"time"
)

type Room struct {
	users        map[net.Conn]*User
	messages     chan string
	lock         sync.Mutex
	server       *Server
	playerChoice sync.Map
	mode         string
}

func NewRoom(server *Server) *Room {
	room := &Room{
		users:    make(map[net.Conn]*User, 2),
		messages: make(chan string),
		server:   server,
		mode:     "wait",
	}

	return room
}

func (this *Room) Join(user *User) {
	this.mode = "wait"
	go this.ListenMessager()

	this.lock.Lock()
	this.users[user.conn] = user
	user.room = this
	this.lock.Unlock()

	if len(this.users) == 2 {
		this.lock.Lock()
		this.mode = "start" // 更新房间模式
		this.lock.Unlock()
		this.SysBroadCast("房间已存在两位玩家，请开始游戏")
		this.SysOrderBroadCast("stop()") // 发送停止指令
	} else if len(this.users) == 1 {
		this.SysBroadCast("房间正在等待另一位玩家加入...")
	}
}

func (this *Room) Leave(conn net.Conn) {
	//检查指针是否为 nil
	if this == nil {
		fmt.Println("Room pointer is nil, cannot call Leave")
		return
	}

	this.lock.Lock()
	delete(this.users, conn)
	this.lock.Unlock()

	// 根据剩余用户数量处理逻辑
	switch len(this.users) {
	case 0:
		// 如果没有用户，触发 RoomCheck
		if this.server != nil {
			go this.RoomCheck()
		}
	case 1:
		// 如果只剩一个用户，修改 mode 为 "wait"
		this.mode = "wait"
		this.SysBroadCast("玩家已离开，房间正在等待另一位玩家加入...")
	default:
		this.SysBroadCast("No player here.\n")
	}
}

func (this *Room) SysOrderBroadCast(msg string) {
	this.messages <- msg
}

func (this *Room) SysBroadCast(msg string) {
	this.lock.Lock()
	this.messages <- "[System]" + ":" + msg
	this.lock.Unlock()
}

func (this *Room) GameMsgHandler(user *User, msg string) {
	if msg == "剪刀" || msg == "石头" || msg == "布" {
		fmt.Println(user, msg)
		this.playerChoice.Store(user.conn, msg)
		this.DetermineWinnerAndBroadcast()
	}
}

func (this *Room) MsgHandler(user *User, msg string) {
	fmt.Println("room mode", this.mode, msg)
	switch this.mode {
	case "wait":
		this.SysBroadCast("请等待另一位玩家加入...")
	case "start":
		this.GameMsgHandler(user, msg)
	}
}

func (this *Room) DetermineWinnerAndBroadcast() {
	var choices [2]string
	var users [2]*User
	this.playerChoice.Range(func(key, value interface{}) bool {
		name := key.(net.Conn)
		choice := value.(string)

		var userVal = this.users[name]
		if userVal != nil {
			user := userVal
			if users[0] == nil {
				users[0] = user
				choices[0] = choice
			} else {
				users[1] = user
				choices[1] = choice
				return false
			}
		}
		return true
	})

	//将结果分别传进通道
	if users[1] != nil {
		result1, result2 := this.DetermineWinner(choices[:])
		fmt.Printf("result -- user %s: %s\n", users[0].Name, result1)
		fmt.Printf("result -- user %s: %s\n", users[1].Name, result2)
		users[0].Channel <- result1
		users[1].Channel <- result2
		this.playerChoice = sync.Map{}
	}
}

func (this *Room) DetermineWinner(choices []string) (string, string) {
	if choices[0] == choices[1] {
		return "平局！", "平局！"
	} else if (choices[0] == "剪刀" && choices[1] == "布") ||
		(choices[0] == "石头" && choices[1] == "剪刀") ||
		(choices[0] == "布" && choices[1] == "石头") {
		return "你赢了！", "你输了！"
	} else {
		return "你输了！", "你赢了！"
	}
}

// 监听管道
func (this *Room) ListenMessager() {
	for {
		// 从Message管道中读取消息
		msg := <-this.messages

		if msg == "stop()" {
			break
		}

		this.lock.Lock()
		// 遍历在线用户，把广播消息同步给房间内用户
		for _, user := range this.users {
			// 把要广播的消息写到用户管道中
			user.Channel <- msg
		}
		this.lock.Unlock()
	}
}

func (this *Room) RoomCheck() {
	timer := time.NewTimer(time.Second * 10)
	defer timer.Stop()

	select {
	case <-timer.C:
		this.lock.Lock()
		defer this.lock.Unlock()

		if len(this.users) == 0 {
			if this.server != nil { // 确保 server 不为 nil
				delete(this.server.Rooms, this) // 删除房间
				fmt.Println("Room delete...")
			}
			close(this.messages)
			this.server = nil
		}
	}
}
