package main

import (
	"GoSocketServer/test"
	"fmt"
	"github.com/golang/protobuf/proto"
	"net"
)

type User struct {
	Name    string      //昵称
	Addr    string      //地址
	Channel chan string //消息管道
	conn    net.Conn    //连接
	server  *Server     //缓存Server的引用
	room    *Room       //缓存Room的引用
}

// 定义一个newuser全局方法 构造user对象 提供给外部
func NewUser(conn net.Conn, server *Server) *User {
	userAddr := conn.RemoteAddr().String()
	user := &User{
		Name:    userAddr,
		Addr:    userAddr,
		Channel: make(chan string),
		conn:    conn,
		server:  server,
	}
	// 启动协程，监听Channel管道消息
	go user.ListenMessage()
	return user
}

func (this *User) Online() {
	//用户上限，将用户加入到onlinemap中，注意枷锁操作
	fmt.Println("onlineMap加锁...")
	this.server.mapLock.Lock()
	this.server.OnlineMap[this.conn] = this
	this.server.mapLock.Unlock()

	//广播当前用户下线消息
	//this.server.BroadCast(this, "上线啦O(∩_∩)O")
}

func (this *User) Offline() {

	// 用户下线，将用户从OnlineMap中删除，注意加锁
	this.server.mapLock.Lock()
	this.room.Leave(this.conn)
	delete(this.server.OnlineMap, this.conn)
	this.server.mapLock.Unlock()

	// 广播当前用户下线消息
	//this.server.BroadCast(this, "下线了o(╥﹏╥)o")
}

func (this *User) DoMessage(buf []byte, len int) {
	newmsg := &test.PbMsg{}
	//fmt.Println("LEN", buf[:len])
	var err = proto.Unmarshal(buf[:len], newmsg)
	if err != nil {
		fmt.Println("ERR")
	}

	msg := newmsg.PlayerChoice
	if msg == "加入房间" {
		this.server.Join(this)
		return
	}
	if this.room != nil {
		this.room.MsgHandler(this, msg)
	}

}

func (this *User) ListenMessage() {
	for {
		msg := <-this.Channel
		fmt.Println("Send msg to client: ", msg, ", len: ", int16(len(msg)))

		pbInfo := &test.PbMsg{}
		pbInfo.Result = msg
		fmt.Println(pbInfo.Result)

		marshal, err := proto.Marshal(pbInfo)
		if err != nil {
			return
		}
		fmt.Printf("Marshal转成二进制结果：%v\n", marshal)
		fmt.Println(len(marshal))

		// 发送消息给客户端
		_, err = this.conn.Write(marshal)
		if err != nil {
			fmt.Println("Error sending message: ", err)
			return // 如果发送失败，退出循环
		}
	}
}
